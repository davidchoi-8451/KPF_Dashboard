# Databricks notebook source
import pyspark

# COMMAND ----------

# MAGIC %md
# MAGIC ### Last Backed Up Date: 5/28/2026

# COMMAND ----------

# MAGIC %md
# MAGIC #### Offsite XCM / DISP Backup

# COMMAND ----------

# Offsite Backup Path: 'abfss://data-shuttle@sa8451denblrdatamoverdev.dfs.core.windows.net/d199104/kpf_dashboard/absolute_iroas_xcm_disp_backup'
 
final_result_xcm_disp_df_test = spark.read.parquet(
    'abfss://data-shuttle@sa8451denblrdatamoverdev.dfs.core.windows.net/d199104/kpf_dashboard/absolute_iroas_xcm_disp'
)

backup_path_xcm = 'abfss://data-shuttle@sa8451denblrdatamoverdev.dfs.core.windows.net/d199104/kpf_dashboard/absolute_iroas_xcm_disp_backup'

(
    final_result_xcm_disp_df_test
    .coalesce(1)
    .write
    .mode("overwrite")
    .parquet(backup_path_xcm)
)

# Read the backup file and display it
backup_df_xcm = spark.read.parquet(backup_path_xcm)
display(backup_df_xcm)

# COMMAND ----------

# MAGIC %md
# MAGIC #### MCP SSE Backup

# COMMAND ----------

# MCP SSE Backup Path: 'abfss://data-shuttle@sa8451denblrdatamoverdev.dfs.core.windows.net/d199104/kpf_dashboard/absolute_iroas_mcp_sse_backup'
 
final_result_mcp_sse_df_test = spark.read.parquet(
    f'abfss://data-shuttle@sa8451denblrdatamoverdev.dfs.core.windows.net/d199104/kpf_dashboard/absolute_iroas_mcp_sse'
)

backup_path_mcp_sse = 'abfss://data-shuttle@sa8451denblrdatamoverdev.dfs.core.windows.net/d199104/kpf_dashboard/absolute_iroas_mcp_sse_backup'

(
    final_result_mcp_sse_df_test
    .coalesce(1)
    .write
    .mode("overwrite")
    .parquet(backup_path_mcp_sse)
)

# Read the backup file and display it
backup_df_mcp_sse = spark.read.parquet(backup_path_mcp_sse)
display(backup_df_mcp_sse)

# COMMAND ----------

# MAGIC %md
# MAGIC #### REM SSE PUSH 4x Backup

# COMMAND ----------

# REM SSE PUSH 4x Backup Path: 'abfss://data-shuttle@sa8451denblrdatamoverdev.dfs.core.windows.net/d199104/kpf_dashboard/absolute_iroas_rem_sse_push_xcm'
 
final_result_rem_sse_push_test = spark.read.parquet(
    f'abfss://data-shuttle@sa8451denblrdatamoverdev.dfs.core.windows.net/d199104/kpf_dashboard/absolute_iroas_rem_sse_push_xcm'
)

backup_path_rem_sse_push_4x = 'abfss://data-shuttle@sa8451denblrdatamoverdev.dfs.core.windows.net/d199104/kpf_dashboard/absolute_iroas_rem_sse_push_xcm_backup'

(
    final_result_rem_sse_push_test
    .coalesce(1)
    .write
    .mode("overwrite")
    .parquet(backup_path_rem_sse_push_4x)
)

# Read the backup file and display it
backup_df_rem_sse_push_4x = spark.read.parquet(backup_path_rem_sse_push_4x)
display(backup_df_rem_sse_push_4x)

# COMMAND ----------

# MAGIC %md
# MAGIC #### TDC + EMOD Backup

# COMMAND ----------

# TDC Backup Path: 'abfss://data-shuttle@sa8451denblrdatamoverdev.dfs.core.windows.net/d199104/kpf_dashboard/absolute_iroas_tdc'
 
final_result_tdc_test = spark.read.parquet(
    f'abfss://data-shuttle@sa8451denblrdatamoverdev.dfs.core.windows.net/d199104/kpf_dashboard/absolute_iroas_tdc'
)

backup_path_tdc = 'abfss://data-shuttle@sa8451denblrdatamoverdev.dfs.core.windows.net/d199104/kpf_dashboard/absolute_iroas_tdc_backup'

(
    final_result_tdc_test
    .coalesce(1)
    .write
    .mode("overwrite")
    .parquet(backup_path_tdc)
)

# Read the backup file and display it
backup_df_tdc = spark.read.parquet(backup_path_tdc)
display(backup_df_tdc)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Combined ABS IROAS Backup

# COMMAND ----------

# Combined Backup Path: 'abfss://data-shuttle@sa8451denblrdatamoverdev.dfs.core.windows.net/d199104/kpf_dashboard/absolute_iroas_all_camp_types'
 
final_result_combined_test = spark.read.parquet(
    f'abfss://data-shuttle@sa8451denblrdatamoverdev.dfs.core.windows.net/d199104/kpf_dashboard/absolute_iroas_all_camp_types'
)

backup_path_combined = 'abfss://data-shuttle@sa8451denblrdatamoverdev.dfs.core.windows.net/d199104/kpf_dashboard/absolute_iroas_all_camp_types_backup'

(
    final_result_combined_test
    .coalesce(1)
    .write
    .mode("overwrite")
    .parquet(backup_path_combined)
)

# Read the backup file and display it
backup_df_combined = spark.read.parquet(backup_path_combined)
display(backup_df_combined)